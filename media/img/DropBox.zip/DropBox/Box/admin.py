from django.contrib import admin
from Box.models import user_files
# Register your models here.

admin.site.register(user_files)