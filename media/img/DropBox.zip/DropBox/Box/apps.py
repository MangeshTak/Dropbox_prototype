from django.apps import AppConfig


class BoxConfig(AppConfig):
    name = 'Box'
